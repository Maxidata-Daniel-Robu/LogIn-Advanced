﻿using System;
using System.ComponentModel;
using System.Runtime.CompilerServices;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Input;
using System.Windows.Media;
using test.Commands;
using test.Models;

namespace test.ViewModels
{
    public class LoginViewModel : INotifyPropertyChanged
    {
        private string _username = string.Empty;
        private string _password = string.Empty;
        private string _statusMessage = string.Empty;
        private Brush _statusColor = Brushes.Red;
        private int _loginAttempts = 0;

        public string Username
        {
            get => _username;
            set { _username = value; OnPropertyChanged(); }
        }

        public string Password
        {
            get => _password;
            set
            {
                _password = value;
                Console.WriteLine($"Password updated in ViewModel: '{_password}'"); // Debug line
                OnPropertyChanged();
            }
        }

        public string StatusMessage
        {
            get => _statusMessage;
            set { _statusMessage = value; OnPropertyChanged(); }
        }

        public Brush StatusColor
        {
            get => _statusColor;
            set { _statusColor = value; OnPropertyChanged(); }
        }

        public ICommand LoginCommand { get; }
        public ICommand NavigateToRegisterCommand { get; }

        public LoginViewModel()
        {
            LoginCommand = new RelayCommand(ExecuteLogin, CanExecuteLogin);
            NavigateToRegisterCommand = new RelayCommand(_ =>
            {
                MainWindow.AppNavigationService.NavigateTo("Register");
            });
        }

        private async void ExecuteLogin(object? parameter)
        {
            if (string.IsNullOrWhiteSpace(Username))
            {
                StatusMessage = "Please enter your username.";
                StatusColor = Brushes.Red;
                return;
            }

            if (string.IsNullOrWhiteSpace(Password))
            {
                StatusMessage = "Please enter your password.";
                StatusColor = Brushes.Red;
                return;
            }

            var user = UserStorage.GetUser(Username, Password);

            if (user != null)
            {
                StatusMessage = "Login successful!";
                StatusColor = Brushes.Green;
                await Task.Delay(500);
                Application.Current.Shutdown();
            }
            else
            {
                _loginAttempts++;
                StatusMessage = $"Invalid username or password. Attempt {_loginAttempts} of 3.";
                StatusColor = Brushes.Red;

                if (_loginAttempts >= 3)
                {
                    await Task.Delay(500);
                    Application.Current.Shutdown();
                }
            }
        }

        private bool CanExecuteLogin(object? parameter) => true;

        public event PropertyChangedEventHandler? PropertyChanged;
        protected void OnPropertyChanged([CallerMemberName] string? name = null)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(name));
        }
    }
}
