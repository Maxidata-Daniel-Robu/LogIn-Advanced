﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Input;

namespace test
{
    public partial class LoginPage : Page
    {
        public LoginPage()
        {
            InitializeComponent();
        }

        private void RegisterLink_Click(object sender, MouseButtonEventArgs e)
        {
            NavigationService?.Navigate(new RegisterPage());
        }

        // ✅ PasswordBox_PasswordChanged method removed
    }
}
